# Лабораторная работа 2 — исходники

В архиве — исходники отчёта и презентации, изображения, библиография и настройки сборки. Готовые PDF/DOCX/HTML приложены отдельно в папках `report/_output/` и `presentation/_output/`.

Основные файлы: `report/infosec-intro-lab02-report.qmd`, `presentation/infosec-intro-lab02-presentation.qmd`; полная таблица 2.1: `report/lab02-table21.tsv`.
